Story Mode Heists DLC by fabian_gunman

https://www.fabianwennink.nl

-----------------------------------
THE DEVELOPMENT OF NEW MISSIONS HAS BEEN HALTED! UPCOMING UPDATES WILL ONLY CONTAIN BUGFIXES! 
-----------------------------------

The changelog can be found at: https://github.com/nlgamevideosnl/StoryModeHeists/blob/master/CHANGELOG.md
If you find a bug, please report it at: https://github.com/nlgamevideosnl/StoryModeHeists/issues.

-----------------------------------

Press F5 to activate the mod! 
Press SHIFT + NUMPAD0 to cancel a mission. 

Because Rockstar isn't planning on adding new heists (http://www.pcgamer.com/no-new-gta-online-heists-anytime-soon-rockstar-says/)
to GTA 5 Online anytime soon, I took matters into my own hands and created the Story Mode Heists DLC mod.

-----------------------------------

Description:
This mod brings brand new GTA 5 Online-like heists to singleplayer. Every heists will, - just like in online -, have multiple setup missions 
and 1 finale mission where you and your crew will be paid. 

You will play as Michael, who will work together with Franklin, Trevor and Lester to complete each heist and earn some big bucks.

Lester will be spawned in his house at El Burro Heights, marked with a green 'H' on the map. In his house you will plan each heist, before 
eventually doing the missions. 

-----------------------------------

First time launching: (! MOD SPOILER ALERT !)
When you launch your game for the first time after installing the mod, Lester will contact you (Michael), telling you that he has some jobs 
available which you might be interested in. After receiving the text message, his home (green 'H') will spawn on the map at El Burro Heights. 

Now after spawning the green 'H', you can go and start playing. Drive to the 'H' and prepare for the 'cutscene'. 

-----------------------------------

Current included heists:
Daddy's Little Girl (4 setup missions, 1 finale):
The daughter of a multi-milionair has been kidnapped by some local gang, demanding millions of dollars in return for her release.

-----------------------------------

Important notes:
My native language is not English, so there might be some errors in the conversations, mission objectives or even in text messages. 

Because it's impossible for me to get the real voices of the voice actors, I decided not to add any conversation sounds in the mod at all. 
All conversations between characters will just be 'subtitles' and will be marked with their name in front of the sentence so you know who says what.

To handle respawn better, I've created some 'nasty' code which will terminate certain game tasks, for example: You won't respawn at the 
hospital and you won't actually die if you get 'killed'.

Cause creating the real Wasted, Mission Failed and Mission Passed screen is 'impossible', I've recreated them myself with text, shapes and screen 
effects just to make it feel real again.

Sometimes the custom 'wasted' screen might bug, if it spawns you at the hospital, please report this to me and restart the mission.

Features like character animations and kill counts will be added in upcoming updates, as well as new heists.

-----------------------------------

Requirements:
1) ScriptHookV by Alexander Blade (http://www.dev-c.com/gtav/scripthookv/)
2) ScriptHookV .NET by Crosire (Version 2.10.2 or higher, https://www.gta5-mods.com/tools/scripthookv-net) 
3) Microsoft .NET Framework (4.5.2 or higher, http://www.microsoft.com/en-us/download/details.aspx?id=42642)
4) C++ Redistributable Packages 2013 (http://www.microsoft.com/en-us/download/details.aspx?id=40784)

-----------------------------------

Installation:
1) Install all requirements
2) Extract the downloaded archive.
3) Copy all extracted files into the \scripts\ folder.

-----------------------------------

Translations:
Since version 1.3.0 a locale file has been added to the mod (StoryModeHeistsLocale.ini), making it possible for people to translate the mod.

Different languages can be found in the 'Languages' folder inside the zip. To switch languages, copy the content of the language you want to use 
into the StoryModeHeistsLocale.ini file and reload your save-game.

If you've translated the locale file into a not already added language, you can submit it to me by uploading it at http://pastebin.com and posting the link 
in the comments. If your translation gets accepted, the file will be added to the mod in a future update.

-----------------------------------

Known bugs:
- The custom Wasted screen might sometimes respawn you at the hospital.
- Your 'bodyguards' will keep shooting after you lost your wanted level. This does not affect your own wanted level.
- The 'bodyguards' might sometimes forget their objective, breaking the mission. In this case you should restart the mission.

-----------------------------------

Other:
Please do not use any of my code without my permission. If you like my mod, please consider making a small donation for my work. 
If you decide to make a video about this mod on YouTube, please add a link to this page in the video description.