   _____       __           __     __  ___                
  / ___/__  __/ /__  ____  / /_   /  |/  /__  ____  __  __
  \__ \/ / / / / _ \/ __ \/ __/  / /|_/ / _ \/ __ \/ / / /
 ___/ / /_/ / /  __/ / / / /_   / /  / /  __/ / / / /_/ / 
/____/\__, /_/\___/_/ /_/\__/  /_/  /_/\___/_/ /_/\__,_/  
     /____/                                                        


Info

Téléchargé sur: https://getmods.net

Version: v1.9

1. Exécutez le fichier "CLICK_HERE(first_time).cmd"
2. Lancez GTAV
3. Lancez "Xenos64.exe"
4. Glissez-déposez le fichier "Sylent.dll" dans la fenêtre Xenos64
5. Choisissez "GTA5.exe" dans le menu déroulant à droite de "Process"
6. Cliquez sur "Inject" puis revenez sur GTAV
7. Ouvrez le menu avec "*" du pavé tactile ou la touche F5 [Manette Xbox: RB + flèche droite ; Manette PS3-4: R1 + flèche de droite]
8. Pour naviguer: [bas:2 ; haut:8; gauche:4; droite:6; entrer:5; retour:0]
8. Faites vous plaisir ;) Mais soyez discrets :D

Téléchargé sur: https://getmods.net