   __  ___              
  / / / _ \ _   _ _   _ 
 / / | | | | | | | | | |
/ /__| |_| | |_| | |_| |
\____/\___/ \__, |\__, |
            |___/ |___/ 


Subscribe on Youtube:   https://www.youtube.com/channel/UCwrstA_ZY-6RUKvBS1Bqpqw

Join the L0yy Discord:   https://discord.gg/QRDd3vx


1. Unzip the Zip File
________________________________________________________________________________
2. Put the L0yyFiles Folder onto the "Move the L0yyFiley folder here" Folder [Appdata]
________________________________________________________________________________

3. Start GTA-V Storymode
________________________________________________________________________________

3. Open Xenos64.exe : 
     - Select GTA.exe as process
     - Drag the "L0yy v1.1" DLL in  the white box
     - Press Inject and wait

________________________________________________________________________________

Menu Controlls: 
________________________________________________________________________________

Open: F5, * 
Up:    Numpad 8, Arrow Up
Down:  Numpad 2, Arrow Down
Left:  Numpad 4, Arrow Left
Right: Numpad 6, Arrow Right
Enter: Numpad 5, Enter Key
Back:  Numpad 0, ESC

Controllers are Supported !
