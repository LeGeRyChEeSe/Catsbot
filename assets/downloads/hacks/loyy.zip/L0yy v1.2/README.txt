

          
╔═════════════════════════════════════════════════════════════════════════════════════════════════════╗                         
║        _     ___                __  __                     _       ____                             ║
║       | |   / _ \ _   _ _   _  |  \/  | ___ _ __  _   _   / |     |___ \                            ║
║       | |  | | | | | | | | | | | |\/| |/ _ \ '_ \| | | |  | |       __) |                           ║
║══════ | |__| |_| | |_| | |_| | | |  | |  __/ | | | |_| |  | |  _   / __/  ══════════════════════════║
║       |_____\___/ \__, |\__, | |_|  |_|\___|_| |_|\__,_|  |_| (_) |_____|                           ║
║                   |___/ |___/                                                                       ║
╚═════════════════════════════════════════════════════════════════════════════════════════════════════╝                        
 

╔════════════════════════════════════════════════════════════════════════╗
║   Comment faire :                                                      ║
║                                                                        ║
╠════════════════════════════════════════════════════════════════════════╩═══════════════════════════════════╗
║  ●  Décompressez le dossier                                                                                ║                   
║                                                                                                            ║
║  ●  Exécutez le script "CLICK_HERE(first_time).cmd"                                                        ║
║                                                                                                            ║
║  ●  Lancez GTA 5                                                                                           ║
║                                                                                                            ║
║  ●  Ouvrez Xenos64                                                                                         ║
║                                                                                                            ║ 
║     Xenos :                                                                                                ║
║                                                                                                            ║
║                                                                                                            ║
║    ═  Selectionnez le processus GTA5.exe                                                                   ║
║                                                                                                            ║
║    ═  Déplacez le fichier "L0yy_v1.2.dll" dans la fenêtre blanche (Ou appuyez sur "Add" et                 ║
║       selectionnez le dll)                                                                                 ║
║                                                                                                            ║ 
║    ═  Appuyez sur "Inject"                                                                                 ║
║                                                                                                            ║                                                                                                             ║       
║                                                                                                            ║
║  ●  Après quelques secondes vous verrez un message indiquant que LOyy est bien injecté apparaître dans GTA ║
╚════════════════════════════════════════════════════════════════════════════════════════════════════════════╝


    ◄► Prenez du plaisir et n'oubliez pas de rejoindre notre serveur discord :) ◄► 

               ◄► https://discord.gg/QRDd3vx ◄►